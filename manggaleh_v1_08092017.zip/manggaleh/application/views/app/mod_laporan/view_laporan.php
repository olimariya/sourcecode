            <div class="col-xs-12">  
              <div class="box">
                <div class="box-header">
                  <h3 class="box-title"><?php echo $judul; ?></h3>
                </div><!-- /.box-header -->
                <div class="box-body">
                  <center style='padding:7%; 0'><img src='<?php echo base_url(); ?>asset/loading.gif'></center>
              </div>