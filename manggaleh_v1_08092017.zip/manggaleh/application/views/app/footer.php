
<strong>Copyright &copy; 2015 - <?php echo date('Y'); ?> <a target='_BLANK' href="https://members.phpmu.com"> Point of Sales</a>.</strong> All rights reserved.