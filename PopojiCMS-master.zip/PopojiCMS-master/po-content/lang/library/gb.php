<?php
/**
 *
 * - PopojiCMS Library Language
 *
 * - File : gb.php
 * - Version : 1.0
 * - Author : Jenuar Dalapang
 * - License : MIT License
 *
*/

$_['component_name'] = 'Library';
$_['library_name'] = 'Name';
$_['library_type'] = 'Type';
$_['library_size'] = 'Size';
$_['library_date'] = 'Modified';
$_['library_action'] = 'Action';
$_['library_addnew'] = 'Add Library';
$_['library_message_1'] = 'Library has been successfully added';
$_['library_message_2'] = 'Library has been successfully deleted';
$_['library_message_3'] = 'Error added new library data';
$_['library_message_4'] = 'Error deleted library data';
