<?php
/**
 *
 * - PopojiCMS Comment Language
 *
 * - File : id.php
 * - Version : 1.0
 * - Author : Jenuar Dalapang
 * - License : MIT License
 *
*/

$_['component_name'] = 'Komentar';
$_['comment_name'] = 'Komentar';
$_['comment_date'] = 'Tanggal & Jam';
$_['comment_publish'] = 'Terbitkan';
$_['comment_action'] = 'Tindakan';
$_['comment_read'] = 'Tandai Sudah di Baca';
$_['comment_notread'] = 'Tandai Belum di Baca';
$_['comment_act_publish'] = 'Terbitkan Komentar';
$_['comment_act_notpublish'] = 'Jangan Terbitkan Komentar';
$_['comment_view'] = 'Lihat';
$_['comment_reply'] = 'Balas';
$_['comment_dialog_title_1'] = 'Detail';
$_['comment_dialog_title_2'] = 'Balas';
$_['comment_message_1'] = 'Balasan komentar telah berhasil dipostkan';
$_['comment_message_2'] = 'Komentar telah berhasil dihapus';
$_['comment_message_3'] = 'Kesalahan mempost balasan komentar';
$_['comment_message_4'] = 'Kesalahan menghapus data komentar';
