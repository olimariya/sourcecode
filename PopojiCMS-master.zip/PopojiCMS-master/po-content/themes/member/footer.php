<footer>
	<div class="container-fluid">
		<div class="container footer-page">
			<div class="row">
				<p class="text-center"><?=$this->pocore()->call->posetting[0]['value'];?> &copy; 2013-<?=date('Y');?>. All Rights Reserved.</p>
			</div>
		</div>
	</div>
</footer>