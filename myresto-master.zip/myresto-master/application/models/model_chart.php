<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Model_chart extends CI_Controller{

	function __Construct(){
		parent::__Construct();
		$this->load->database();
	}
	
	
	

}