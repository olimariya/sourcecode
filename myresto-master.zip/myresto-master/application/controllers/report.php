<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Report extends CI_Controller{

	function __Construct(){
		parent::__Construct();
	}

}