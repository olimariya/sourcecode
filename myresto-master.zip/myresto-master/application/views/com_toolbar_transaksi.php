<div id="toolbar">
	<ul>
		<li><a href="javascript:void(0)" class="down"><img src="<?php echo base_url();?>assets/img/down-arrow.png" class="icon"/>Tampilkan Header</a></li>
		<li><a href="javascript:void(0)" class="up"><img src="<?php echo base_url();?>assets/img/up-arrow.png" class="icon"/>Sembunyikan Header</a></li>
		<li><a href="javascript:void(0)"><img src="<?php echo base_url();?>assets/img/chat.png" class="icon"/>Bantuan</a></li>
		<li><a href="javascript:void(0)"><img src="<?php echo base_url();?>assets/img/admin.png" class="icon"/>Casheir : Casheir</a></li>
		<li><a href="javascript:void(0)"><img src="<?php echo base_url();?>assets/img/Calender.png" class="icon"/><span class="tanggal">Tanggal</span></a></li>
		<li><a href="javascript:void(0)"><img src="<?php echo base_url();?>assets/img/time.png" class="icon"/><span class="waktu">Waktu</span> WIB</a></li>
		<li><a href="<?php echo base_url('index.php/admin/logout');?>"><img src="<?php echo base_url();?>assets/img/unlock.png" class="icon"/>Logout</a></li>
	</ul>
</div>