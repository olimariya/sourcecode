<div id="navigasi">
				<ul>
					<a href="javascript:void(0)"><li class="title"><span><img src="<?php echo base_url();?>assets/img/folder_with_file.png" class="icon"/>Master Data</span></li></a>
					<a href="<?php echo base_url('menu');?>"><li><span><img src="<?php echo base_url();?>assets/img/menu.png" class="icon"/>Daftar Menu</span></li></a>
					<a href="<?php echo base_url('bahan');?>"><li><span><img src="<?php echo base_url();?>assets/img/bahan.png" class="icon"/>Bahan Baku</span></li></a>
					<a href="<?php echo base_url('meja');?>"><li><span><img src="<?php echo base_url();?>assets/img/meja.png" class="icon"/>Meja</span></li></a>
					<a href="<?php echo base_url('pegawai');?>"><li><span><img src="<?php echo base_url();?>assets/img/admin.png" class="icon"/>Pegawai</span></li></a>
					<a href="<?php echo base_url('supplier');?>"><li><span><img src="<?php echo base_url();?>assets/img/icon.ingr-database.png" class="icon"/>Supplier</span></li></a>
				</ul>
				<ul>
					<a href="javascript:void(0)"><li class="title"><span><img src="<?php echo base_url();?>assets/img/Cash.png" class="icon"/>Data Transaksi</span></li></a>
					<a href="<?php echo base_url('penjualan');?>"><li><span><img src="<?php echo base_url();?>assets/img/Cash.png" class="icon"/>Penjualan</span></li></a>
					<a href="<?php echo base_url('pembelian');?>"><li><span><img src="<?php echo base_url();?>assets/img/Pembayaran.png" class="icon"/>Pembelian Bahan</span></li></a>
					<a href="<?php echo base_url('pembayaran');?>"><li><span><img src="<?php echo base_url();?>assets/img/Commerce_1.png" class="icon"/>Pembayaran Lainnya</span></li></a>
				</ul>
				<ul>
					<a href="javascript:void(0)"><li class="title"><span><img src="<?php echo base_url();?>assets/img/Chart.png" class="icon"/>Statistik</span></li></a>
					<a href="<?php echo base_url('chart/penjualan');?>"><li><span><img src="<?php echo base_url();?>assets/img/Cash.png" class="icon"/>Pendapatan / Penjualan</span></li></a>
					<a href="<?php echo base_url('chart/pengeluaran');?>"><li><span><img src="<?php echo base_url();?>assets/img/Pembayaran.png" class="icon"/>Pengeluaran</span></li></a>
					<a href="<?php echo base_url('chart/labarugi');?>"><li><span><img src="<?php echo base_url();?>assets/img/15194618.png" class="icon"/>Pendapatan & Pengeluaran</span></li></a>
				</ul>
				<ul>
					<a href="javascript:void(0)"><li class="title"><span><img src="<?php echo base_url();?>assets/img/Fix.png" class="icon"/>Pengaturan</span></li></a>
					<a href="<?php echo base_url('kategori');?>"><li><span><img src="<?php echo base_url();?>assets/img/menu.png" class="icon"/>Kategori Menu</span></li></a>
					<a href="<?php echo base_url('extra');?>"><li><span><img src="<?php echo base_url();?>assets/img/menu.png" class="icon"/>Menu Extra</span></li></a>
					<a href="<?php echo base_url('posisi');?>"><li><span><img src="<?php echo base_url();?>assets/img/admin.png" class="icon"/>Posisi Pegawai</span></li></a>
					<a href="<?php echo base_url('pedas');?>"><li><span><img src="<?php echo base_url();?>assets/img/fire.png" class="icon"/>Level Kepedasan</span></li></a>
					<a href="<?php echo base_url('profil');?>"><li><span><img src="<?php echo base_url();?>assets/img/contact.png" class="icon"/>Profil Perusahaan</span></li></a>
					<a href="javascript:void(0)" id="do_reset"><li><span><img src="<?php echo base_url();?>assets/img/update.png" class="icon"/>Reset Data</span></li></a>
				</ul>
			</div>