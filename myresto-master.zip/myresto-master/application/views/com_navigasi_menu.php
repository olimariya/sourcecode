<div id="navigasi">
	
	<ul>
		<a href="javascript:void(0)" class="kategori">
			<li class="title">
				<span>
					<img src="<?php echo base_url();?>assets/img/Menu.png" class="icon"/>
						
				</span>
			</li>
		</a>
		
		
	</ul>	
	
		
</div>