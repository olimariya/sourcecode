<div id="header">
	<div class="logo">
		<img src="<?php echo base_url('assets/img/header_bg.jpg');?>"/>	
	</div>
</div>

<div id="freset">
	<span><strong>Masukan No Pin :</strong></span>
	<span><input type="password" id="pin" /></span> 
	<span><button id="breset" class="btn">OK</button></span>
</div>