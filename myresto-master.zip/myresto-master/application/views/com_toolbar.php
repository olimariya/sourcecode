<div id="toolbar">
	<ul>
		<li><a href="<?php echo base_url('index.php/home');?>"><img src="<?php echo base_url();?>assets/img/home.png" class="icon"/>Home</a></li>
		<li><a href="javascript:void(0)"><img src="<?php echo base_url();?>assets/img/chat.png" class="icon"/>Bantuan</a></li>
		<li><a href="javascript:void(0)"><img src="<?php echo base_url();?>assets/img/admin.png" class="icon"/>Administrator</a></li>
		<li><a href="javascript:void(0)"><img src="<?php echo base_url();?>assets/img/Calender.png" class="icon"/><span class="tanggal">Tanggal</span></a></li>
		<li><a href="javascript:void(0)"><img src="<?php echo base_url();?>assets/img/time.png" class="icon"/><span class="waktu">Waktu</span> WIB</a></li>
		<li><a href="<?php echo base_url('index.php/admin/logout');?>"><img src="<?php echo base_url();?>assets/img/unlock.png" class="icon"/>Logout</a></li>
	</ul>
</div>