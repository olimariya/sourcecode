$(document).ready(function(){
	$("#container").hide();
	$("#container").slideDown(1000);
});