# Version of Voyager

The current version of Voyager is alpha, and can therefor not be garanteed to be stable.
However we try to keep any breaking changes from the build releases.
Instead we move breaking changes to a minor release instead.
Once a new minor version have been released, migrations will be made in order for people to migrate from the older versions.
It's however still unsure how we will handle the versioning once we're done with the alpha and release the first stable version.
For ideas and feedback for this, please join our Slack team.
