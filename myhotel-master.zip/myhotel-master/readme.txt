- Software Reuirements:

1. PHP 5 or higher
2. Composer
3. MySQL Database

- Important

** Make sure your php openssl are actived. **


#for login :

username : naruto
password : 123

#For Contacts
#Email :  SandyAndryanto27@gmail.com

Best Regards,


