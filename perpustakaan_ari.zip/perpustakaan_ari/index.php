<?php 
    header("location:http://localhost/perpustakaan_ari/administrator/");
?>