<div class="row">
                <div class="col-lg-12">
                    <p>Copyright &copy; Dwi Ariwibowo 2017</p>
                </div>
</div>